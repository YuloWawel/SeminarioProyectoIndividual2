package com.example.julio.proyecto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TabHost;

public class MainActivity extends AppCompatActivity {


    ImageView ivcalcular,quitar,ivcalcular2;
    private EditText celcius,kelvin,faren,kilos,libras,toneladas,onzas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabHost tabHost =  findViewById(R.id.tabHost);
        tabHost.setup();

        TabHost.TabSpec spec = tabHost.newTabSpec("Peso");
        spec.setContent(R.id.Temperatura);
        spec.setIndicator("Peso");
        tabHost.addTab(spec);

        spec = tabHost.newTabSpec("Temperatura");
        spec.setContent(R.id.Peso);
        spec.setIndicator("Temperatura");
        tabHost.addTab(spec);


        quitar=findViewById(R.id.quitar);
        ivcalcular= findViewById(R.id.ivcalcular);
        ivcalcular2= findViewById(R.id.ivcalcular2);
        celcius=(EditText) findViewById(R.id.cel);
        kelvin=(EditText) findViewById(R.id.kel) ;
        faren=(EditText) findViewById(R.id.faren);
        libras= findViewById(R.id.libra);
        kilos=findViewById(R.id.kilogramos);
        onzas=findViewById(R.id.onzas);

        ivcalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cel=celcius.getText().toString();
                String kel=kelvin.getText().toString();
                String far=faren.getText().toString();

                if (cel != Integer.toString(0))
                {
                 double rk= Integer.parseInt(cel)+273.15;
                 double rf= (Integer.parseInt(cel)*1.8)+32;
                kelvin.setText(String.valueOf(rk));
                faren.setText(String.valueOf(rf));
                }else if (far != Integer.toString(0))
                {
                double rk= Integer.parseInt(far)-459.67;
                double rc= (Integer.parseInt(far)-32)/1.8;
                celcius.setText(String.valueOf(rc));
                kelvin.setText(String.valueOf(rk));
                }else if (kel != Integer.toString(0)) {
                    double rf = (Integer.parseInt(kel) - 273.15) * (9 / 5) + 32;
                    double rc = Integer.parseInt(kel) - 273.15;
                    celcius.setText(String.valueOf(rc));
                    kelvin.setText(String.valueOf(rf));
                }
                //else if (cel != Integer.toString(0) && far != Integer.toString(0) && kel != Integer.toString(0))
                //{
               //    celcius.setText(String.valueOf(0));
                //    kelvin.setText(String.valueOf(0));
                 //   faren.setText(String.valueOf(0));
              //  }
            }
        });

        ivcalcular2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String lib=libras.getText().toString();
                String onz=onzas.getText().toString();
                String ton=toneladas.getText().toString();
                String kilo=kilos.getText().toString();

                if (lib != Integer.toString(0))
                {
                    double ronz= Integer.parseInt(lib)*16.000;
                    double rton= (Integer.parseInt(lib)/2204.6);
                    double rkilo= Integer.parseInt(lib)/2.2046;
                    onzas.setText(String.valueOf(ronz));
                    toneladas.setText(String.valueOf(rton));
                    kilos.setText(String.valueOf(rkilo));
                }

                if (kilo != Integer.toString(0))
                {
                    double ronz= Integer.parseInt(lib)*16.000;
                    double rton= (Integer.parseInt(lib)/2204.6);
                    double rkilo= Integer.parseInt(lib)/2.2046;
                    onzas.setText(String.valueOf(ronz));
                    toneladas.setText(String.valueOf(rton));
                    kilos.setText(String.valueOf(rkilo));
                }

                if (ton != Integer.toString(0))
                {
                    double ronz= Integer.parseInt(lib)*16.000;
                    double rton= (Integer.parseInt(lib)/2204.6);
                    double rkilo= Integer.parseInt(lib)/2.2046;
                    onzas.setText(String.valueOf(ronz));
                    toneladas.setText(String.valueOf(rton));
                    kilos.setText(String.valueOf(rkilo));
                }

                if (onz != Integer.toString(0))
                {
                    double ronz= Integer.parseInt(lib)*16.000;
                    double rton= (Integer.parseInt(lib)/2204.6);
                    double rkilo= Integer.parseInt(lib)/2.2046;
                    onzas.setText(String.valueOf(ronz));
                    toneladas.setText(String.valueOf(rton));
                    kilos.setText(String.valueOf(rkilo));
                }

            }
        });

        quitar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                celcius.setText(String.valueOf(0));
                kelvin.setText(String.valueOf(0));
                faren.setText(String.valueOf(0));

            }
        });
    }

}
